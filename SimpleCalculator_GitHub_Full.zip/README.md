# SimpleCalculator (GitHub Actions IPA)

## Cách dùng nhanh (trên iPhone)
1) Tạo repo GitHub mới
2) Upload toàn bộ nội dung zip này lên repo
3) Vào tab Actions -> chọn "Build IPA (Unsigned)" -> Run workflow
4) Chạy xong tải Artifact về (SimpleCalculator-IPA) -> giải nén ra SimpleCalculator.ipa
5) Cài bằng TrollStore (Install IPA) hoặc ESign+

Ghi chú:
- IPA build theo kiểu "unsigned", TrollStore/ESign+ sẽ xử lý cài đặt.
