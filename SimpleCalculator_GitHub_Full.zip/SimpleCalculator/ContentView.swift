import SwiftUI

struct ContentView: View {
    @State private var display = "0"
    @State private var storedValue: Double? = nil
    @State private var pendingOp: Op? = nil
    @State private var isTyping = false

    enum Op { case add, sub, mul, div }

    var body: some View {
        VStack(spacing: 12) {
            Spacer()

            Text(display)
                .font(.system(size: 64, weight: .semibold, design: .rounded))
                .frame(maxWidth: .infinity, alignment: .trailing)
                .lineLimit(1)
                .minimumScaleFactor(0.3)
                .padding(.horizontal, 20)

            VStack(spacing: 10) {
                row(["AC", "÷", "×", "−"])
                row(["7", "8", "9", "+"])
                row(["4", "5", "6", "="], specialEquals: true)
                row(["1", "2", "3", "."])
                HStack(spacing: 10) {
                    button("0", wide: true)
                    button("⌫")
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
        }
        .background(Color(.systemBackground))
    }

    @ViewBuilder
    private func row(_ titles: [String], specialEquals: Bool = false) -> some View {
        HStack(spacing: 10) {
            ForEach(titles, id: \.self) { t in
                if specialEquals && t == "=" {
                    button(t, isEquals: true)
                } else {
                    button(t)
                }
            }
        }
    }

    private func button(_ title: String, wide: Bool = false, isEquals: Bool = false) -> some View {
        let bg: Color = {
            if isEquals { return Color.green.opacity(0.22) }
            if ["+", "−", "×", "÷"].contains(title) { return Color.orange.opacity(0.22) }
            if ["AC", "⌫"].contains(title) { return Color.gray.opacity(0.22) }
            return Color.blue.opacity(0.18)
        }()

        return Button {
            tap(title)
        } label: {
            Text(title)
                .font(.system(size: 24, weight: .semibold, design: .rounded))
                .frame(maxWidth: wide ? .infinity : nil)
                .frame(height: 56)
                .frame(minWidth: wide ? 0 : 56)
                .background(bg)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }

    private func tap(_ t: String) {
        switch t {
        case "AC":
            display = "0"
            storedValue = nil
            pendingOp = nil
            isTyping = false

        case "⌫":
            if isTyping {
                display.removeLast()
                if display.isEmpty { display = "0"; isTyping = false }
            } else {
                display = "0"
            }

        case ".":
            if !isTyping {
                display = "0."
                isTyping = true
            } else if !display.contains(".") {
                display += "."
            }

        case "+", "−", "×", "÷":
            commitPendingIfNeeded()
            storedValue = Double(display) ?? 0
            pendingOp = op(from: t)
            isTyping = false

        case "=":
            guard let op = pendingOp, let a = storedValue else { return }
            let b = Double(display) ?? 0
            let result = apply(op: op, a: a, b: b)
            display = format(result)
            storedValue = nil
            pendingOp = nil
            isTyping = false

        default: // numbers
            if isTyping {
                if display == "0" { display = t } else { display += t }
            } else {
                display = t
                isTyping = true
            }
        }
    }

    private func op(from s: String) -> Op {
        switch s {
        case "+": return .add
        case "−": return .sub
        case "×": return .mul
        default: return .div
        }
    }

    private func commitPendingIfNeeded() {
        if let op = pendingOp, let a = storedValue, isTyping {
            let b = Double(display) ?? 0
            let result = apply(op: op, a: a, b: b)
            display = format(result)
            storedValue = result
            isTyping = false
        }
    }

    private func apply(op: Op, a: Double, b: Double) -> Double {
        switch op {
        case .add: return a + b
        case .sub: return a - b
        case .mul: return a * b
        case .div: return b == 0 ? 0 : a / b
        }
    }

    private func format(_ x: Double) -> String {
        if x.isInfinite || x.isNaN { return "0" }
        if x.rounded() == x { return String(Int(x)) }
        return String(format: "%.8f", x)
            .replacingOccurrences(of: "0+$", with: "", options: .regularExpression)
            .replacingOccurrences(of: "\\.$", with: "", options: .regularExpression)
    }
}
